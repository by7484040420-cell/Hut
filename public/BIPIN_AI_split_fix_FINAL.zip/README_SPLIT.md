# BIPIN AI split-screen fix

`public/app-shell.html` ko replace karo.

Android APK mein:
- Left 38% = BIPIN AI
- Right 62% = Government portal
- Portal native InAppBrowser WebView mein custom x/y/width/height ke saath khulta hai.
- `AI Fill / Assist` existing `bipin-autofill.js` ko portal WebView mein load karta hai.
- `Portal Band Karo` WebView close karta hai.

`@capgo/capacitor-inappbrowser` custom dimensions (width/height/x/y) support karta hai.
